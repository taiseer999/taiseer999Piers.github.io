"""Bald Helper support code."""
